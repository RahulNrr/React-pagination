import React from 'react';

function Posts({loading,posts}) {
    if(loading){
        return <h2>Loading...</h2>;
    }
    return (
        <ul>
            {posts.map(post=>{
                return(
                    <h3 className="user" key={post.id}>
                        {post.title}
                    </h3>
                )
                    
            })}
            </ul>
    );
}

export default Posts;