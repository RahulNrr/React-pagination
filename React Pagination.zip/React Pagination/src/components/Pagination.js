import React from 'react'

const pagination = ({ postsPerPage, totalPosts, paginate }) => {
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
        pageNumbers.push(i)
    }
    return ( <
        div style = {
            { marginLeft: "50%" } } >
        <
        ul className = "pagination" > {
            pageNumbers.map(number => ( <
                div key = { number } >
                <
                button href = '!#'
                onClick = {
                    () => paginate(number) } > { number } < /button> <
                /div>
            ))
        } <
        /ul> <
        /div>
    )
}

export default pagination